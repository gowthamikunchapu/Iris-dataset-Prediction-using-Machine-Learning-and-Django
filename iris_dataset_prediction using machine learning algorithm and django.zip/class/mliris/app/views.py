from django.shortcuts import render
import os
import pickle
from sklearn.neighbors import KNeighborsClassifier

# Get the directory of the current file
dir = os.path.dirname(__file__)
model_path = os.path.join(dir, "model.pkl")

# Load the model at the module level
try:
    with open(model_path, "rb") as f:
        model = pickle.load(f)
except FileNotFoundError:
    model = None  # Handle if model.pkl is missing

# View for handling predictions
def predict(request):
    prediction = None  # Initialize prediction

    if request.method == "POST":
        try:
            # Get data from the POST request
            sl = float(request.POST.get("sl", 0))
            sw = float(request.POST.get("sw", 0))
            pl = float(request.POST.get("pl", 0))
            pw = float(request.POST.get("pw", 0))

            # Check if model was loaded correctly
            if model is None:
                raise ValueError("Model not found or failed to load.")

            # Prepare the data for prediction
            parameters = [[sl, sw, pl, pw]]

            # Make the prediction using the loaded model
            prediction_index = model.predict(parameters)[0]
            classes = ["setosa", "versicolor", "virginica"]
            prediction = classes[prediction_index]

        except ValueError as e:
            prediction = f"Input error: {str(e)}"
        except Exception as e:
            prediction = f"Error in prediction: {str(e)}"

    return render(request, "predict.html", {"prediction": prediction})
